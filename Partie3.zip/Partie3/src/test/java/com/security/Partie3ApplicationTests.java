package com.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Partie3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
